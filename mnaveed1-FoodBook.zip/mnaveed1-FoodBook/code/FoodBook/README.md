CMPUT 301 - Assignment 1
--Description

 * A simple Android application that allows users to record their food items it's details
 * The user is prompted to record the date, description, count, unitcost and best before date of the food item.
 * The user are able to view their previously added food and have the option to delete/edit them.



-- Citations

-CodingWithMitch, "Android DatePicker Dialog Choosing a Date from a Dialog Pop-Up",Apr 6, 2017,  https://www.youtube.com/watch?v=hwe1abDO2Ag&t=1s&ab_channel=CodingWithMitch
- Coding in Flow, “Text Spinner - Android Studio Tutorial” youtube.com, Nov-13-2017.  https://www.youtube.com/watch?v=on_OrrX7Nw4&ab_channel=CodinginFlow.

 
